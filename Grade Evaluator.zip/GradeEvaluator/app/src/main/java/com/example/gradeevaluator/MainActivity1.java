package com.example.gradeevaluator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity1 extends AppCompatActivity {
    EditText ed3, ed4, ed5;
    Button btn3, btn4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main1);
        ed3 = findViewById(R.id.studentname);
        ed4 = findViewById(R.id.deprtname);
        ed5 = findViewById(R.id.Rollno);

        btn3 = findViewById(R.id.btn3);
        btn4 = findViewById(R.id.btn4);

        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity1.this, "sUCCESSFULLY DATA ENTERED", Toast.LENGTH_SHORT).show();
            }
        });
        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(MainActivity1.this,MainActivity.class);
                startActivity(intent);
            }
        });
    }
    }
