package com.example.gradeevaluator;

import static android.text.method.TextKeyListener.clear;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity2 extends AppCompatActivity {
EditText ed1,ed2,ed3,ed4,ed5,ed6,ed7,ed8;
Button btn5,btn6,btn7;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        ed1 = findViewById(R.id.mobile);
        ed2 = findViewById(R.id.sna);
        ed3 = findViewById(R.id.cloud);
        ed4 = findViewById(R.id.human);
        ed5 = findViewById(R.id.internet);
        ed6 = findViewById(R.id.project);
        ed7 = findViewById(R.id.gpa);
        ed8 = findViewById(R.id.cgpa);

        btn5 = findViewById(R.id.btn5);
        btn6 = findViewById(R.id.btn6);
        btn7 = findViewById(R.id.btn7);
   btn7.setOnClickListener(new View.OnClickListener() {
       @Override
       public void onClick(View view) {
           Intent intent=new Intent(MainActivity2.this,MainActivity.class);
           startActivity(intent);
       }
   });

        btn5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                markscal();
            }

            private void markscal() {
                int m1, m2, m3, m4, m5, m6;
                double gpa;
                double cgpa;
                m1 = Integer.parseInt(ed2.getText().toString());
                m2 = Integer.parseInt(ed3.getText().toString());
                m3 = Integer.parseInt(ed4.getText().toString());
                m4 = Integer.parseInt(ed2.getText().toString());
                m5 = Integer.parseInt(ed3.getText().toString());
                m6 = Integer.parseInt(ed4.getText().toString());
                int tot = m1 + m2 + m3 + m4 + m5 + m6;
                ed7.setText(String.valueOf(tot));
                gpa = tot / 3;
                ed8.setText(String.valueOf(gpa));
                if (gpa > 90) {
                    ed8.setText("3.9");
                } else if (gpa > 80) {
                    ed8.setText("3.8");
                } else if (gpa > 70) {
                    ed8.setText("3.5");
                } else if (gpa > 60) {
                    ed8.setText("3.2");
                } else if (gpa > 55) {
                    ed8.setText("2.5");
                } else if (gpa > 50) {
                    ed8.setText("2");
                } else {
                    ed8.setText("fail");
                }

            }
        });
     btn6.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View view) { clear();}

         private void clear() {
         ed1.setText("");
             ed2.setText("");
             ed3.setText("");
             ed4.setText("");
             ed5.setText("");
             ed6.setText("");
             ed7.setText("");
             ed8.setText("");





         }
     });

}
    }
